import "@/App.css";
import InfernoGame from "@/game/InfernoGame";

function App() {
  return (
    <div className="App" data-testid="app-root">
      <InfernoGame />
    </div>
  );
}

export default App;
