import { useEffect, useRef, useState, useCallback } from 'react';
import { Engine } from '@/game/Engine';
import { W as GAME_W, H as GAME_H, PHASES, CLASSES } from '@/game/config';
import { audio } from '@/game/AudioManager';
import { loadSave, clearAllSave } from '@/game/Save';

const ATTRS = [
  { key: 'damage',      ico: '⚔', name: 'FÚRIA',      val: '+15%', desc: 'Dano' },
  { key: 'attackSpeed', ico: '⚡', name: 'FRENESI',    val: '+20%', desc: 'Velocidade de ataque' },
  { key: 'lifesteal',   ico: '✚', name: 'VAMPIRISMO', val: '+10%', desc: 'Roubo de vida' },
  { key: 'defense',     ico: '⛨', name: 'CARNE DURA', val: '+25%', desc: 'Defesa' },
  { key: 'hp',          ico: '♥', name: 'VITALIDADE', val: '+100%', desc: 'Vida máxima' },
];

const NPC_LINES = [
  "Não... não há volta. Esses corredores devoraram milhares como eu.",
  "Belial reina no fundo deste poço. Cada andar é uma camada da minha pena.",
  "Mas seus olhos... ainda têm algo da vida. Talvez você consiga.",
  "Tome um sopro do que restou de mim. Que ele te cure e prolongue seu fio de vida.",
];

function isTouchDevice() {
  if (typeof window === 'undefined') return false;
  return ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
}

export default function InfernoGame() {
  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const spriteRef = useRef(null);
  const rafRef = useRef(null);
  const lastTRef = useRef(0);
  const joystickRef = useRef({ active: false, id: null, cx: 0, cy: 0, kx: 0, ky: 0, maxR: 60 });

  const [screen, setScreen] = useState('menu');
  const [touch] = useState(isTouchDevice());
  const [selectedClass, setSelectedClass] = useState('vampire');
  const [muted, setMuted] = useState(false);
  const [ui, setUi] = useState({
    hp: 100, hpMax: 100, damage: 15, attackSpeed: 1, defense: 5, lifesteal: 0.05,
    level: 1, kills: 0, phase: 1,
    invulnCd: 0, fieldCd: 0, burstCd: 0, invulnTime: 0, fieldTime: 0,
    enemiesLeft: 0, bossSpawned: false, cleared: false, dead: false,
    classId: 'vampire', className: 'VAMPIRO',
  });
  const [npcLineIdx, setNpcLineIdx] = useState(0);
  const [npcBuffed, setNpcBuffed] = useState(false);
  const [nearNpc, setNearNpc] = useState(false);
  const [savedRun, setSavedRun] = useState(null);

  // Detect saved run
  useEffect(() => {
    const s = loadSave();
    setSavedRun(s && s.current ? s : (s && s.best ? s : null));
  }, [screen]);

  // Sprite preload
  useEffect(() => {
    const img = new Image();
    img.src = '/assets/character.png';
    img.onload = () => { spriteRef.current = img; if (engineRef.current) engineRef.current.bindSprite(img); };
  }, []);

  // Engine init
  useEffect(() => {
    engineRef.current = new Engine({
      onUiUpdate: (data) => setUi(data),
      onPhaseClear: () => setScreen('attr'),
      onDeath: () => setScreen('dead'),
      onVictory: () => setScreen('victory'),
      onMeetNpc: () => { setNpcLineIdx(0); setNpcBuffed(false); setScreen('npc'); },
    });
    if (spriteRef.current) engineRef.current.bindSprite(spriteRef.current);
  }, []);

  // Music scene management
  useEffect(() => {
    if (!audio.ctx) return;
    if (screen === 'playing') {
      if (ui.bossSpawned) {
        if (audio._curScene !== 'boss') { audio.startMusic('boss'); audio._curScene = 'boss'; }
      } else {
        if (audio._curScene !== 'dungeon') { audio.startMusic('dungeon'); audio._curScene = 'dungeon'; }
      }
    } else if (screen === 'menu' || screen === 'lore' || screen === 'class') {
      if (audio._curScene !== 'menu') { audio.startMusic('menu'); audio._curScene = 'menu'; }
    } else if (screen === 'dead' || screen === 'victory') {
      audio.stopMusic();
      audio._curScene = null;
    }
  }, [screen, ui.bossSpawned]);

  // Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = GAME_W;
    canvas.height = GAME_H;

    const loop = (t) => {
      const dt = Math.min(0.05, (t - lastTRef.current) / 1000 || 0);
      lastTRef.current = t;
      const eng = engineRef.current;
      if (eng) {
        if (screen === 'playing') eng.update(dt);
        ctx.clearRect(0, 0, GAME_W, GAME_H);
        eng.render(ctx);
        if (screen === 'playing' && eng.npcs && eng.npcs.length) {
          const p = eng.player;
          const close = eng.npcs.some(n => Math.hypot(n.x - p.x, n.y - p.y) < 70);
          if (close !== nearNpc) setNearNpc(close);
        } else if (nearNpc) setNearNpc(false);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [screen, nearNpc]);

  // Keyboard
  useEffect(() => {
    const km = {
      'w': 'up', 'arrowup': 'up',
      's': 'down', 'arrowdown': 'down',
      'a': 'left', 'arrowleft': 'left',
      'd': 'right', 'arrowright': 'right',
      ' ': 'attack', 'j': 'attack',
    };
    const handleDown = (e) => {
      const k = e.key.toLowerCase();
      const eng = engineRef.current;
      if (!eng) return;
      if (k === 'm') { const m = audio.toggleMute(); setMuted(m); return; }
      if (screen !== 'playing') return;
      if (km[k]) { eng.setInput(km[k], true); e.preventDefault(); }
      if (k === 'q') eng.useSkill1();
      if (k === 'r') eng.useSkill2();
      if (k === 'f') eng.useSkill3();
      if (k === 'e') eng.tryInteract();
    };
    const handleUp = (e) => {
      const k = e.key.toLowerCase();
      const eng = engineRef.current;
      if (!eng) return;
      if (km[k]) { eng.setInput(km[k], false); e.preventDefault(); }
    };
    window.addEventListener('keydown', handleDown);
    window.addEventListener('keyup', handleUp);
    return () => {
      window.removeEventListener('keydown', handleDown);
      window.removeEventListener('keyup', handleUp);
    };
  }, [screen]);

  // Mouse attack
  const handleCanvasMouseDown = useCallback(() => {
    const eng = engineRef.current;
    if (eng && screen === 'playing') eng.setInput('attack', true);
  }, [screen]);
  const handleCanvasMouseUp = useCallback(() => {
    const eng = engineRef.current;
    if (eng) eng.setInput('attack', false);
  }, []);

  // Init audio on first interaction
  const ensureAudio = () => {
    if (!audio.ctx) { audio.init(); }
    audio.resume();
  };

  const startGame = () => { ensureAudio(); audio.play('click'); setScreen('lore'); };
  const goClass = () => { ensureAudio(); audio.play('click'); setScreen('class'); };
  const goBack = (s) => { audio.play('click'); setScreen(s); };

  const beginRun = (classId) => {
    ensureAudio();
    audio.play('click');
    engineRef.current.reset(classId);
    if (spriteRef.current) engineRef.current.bindSprite(spriteRef.current);
    setScreen('playing');
  };

  const continueRun = () => {
    ensureAudio();
    audio.play('click');
    const s = loadSave();
    if (!s || !s.current) return;
    const snap = s.current;
    engineRef.current.reset(snap.classId || 'vampire');
    if (spriteRef.current) engineRef.current.bindSprite(spriteRef.current);
    engineRef.current.loadFromSave(snap);
    setScreen('playing');
  };

  const wipeSave = () => {
    audio.play('click');
    clearAllSave();
    setSavedRun(null);
  };

  const pickAttr = (key) => {
    audio.play('click');
    engineRef.current.applyAttribute(key);
    engineRef.current.nextPhase();
    setScreen('playing');
  };

  const advanceNpc = () => {
    audio.play('click');
    if (npcLineIdx < NPC_LINES.length - 1) setNpcLineIdx(npcLineIdx + 1);
    else setScreen('playing');
  };
  const acceptNpcBuff = () => {
    if (!npcBuffed) {
      audio.play('skill1');
      engineRef.current.applyNpcBuff();
      setNpcBuffed(true);
    }
  };

  // Touch joystick
  const onJoyStart = (e) => {
    e.preventDefault();
    const tch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    joystickRef.current = {
      active: true, id: tch.identifier,
      cx: rect.left + rect.width / 2,
      cy: rect.top + rect.height / 2,
      kx: 0, ky: 0,
      maxR: rect.width / 2 - 10,
    };
    updateKnobUI();
  };
  const onJoyMove = (e) => {
    e.preventDefault();
    const j = joystickRef.current;
    if (!j.active) return;
    const tch = Array.from(e.touches).find(tt => tt.identifier === j.id);
    if (!tch) return;
    let dx = tch.clientX - j.cx;
    let dy = tch.clientY - j.cy;
    const d = Math.hypot(dx, dy);
    const max = j.maxR || 60;
    if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
    j.kx = dx; j.ky = dy;
    const eng = engineRef.current;
    if (!eng) return;
    const threshold = 0.25 * max;
    eng.setInput('left', dx < -threshold);
    eng.setInput('right', dx > threshold);
    eng.setInput('up', dy < -threshold);
    eng.setInput('down', dy > threshold);
    updateKnobUI();
  };
  const onJoyEnd = (e) => {
    e.preventDefault();
    const j = joystickRef.current;
    j.active = false; j.kx = 0; j.ky = 0;
    const eng = engineRef.current;
    if (eng) {
      eng.setInput('left', false); eng.setInput('right', false);
      eng.setInput('up', false); eng.setInput('down', false);
    }
    updateKnobUI();
  };
  const updateKnobUI = () => {
    const knob = document.getElementById('joy-knob');
    if (!knob) return;
    const j = joystickRef.current;
    knob.style.transform = `translate(calc(-50% + ${j.kx}px), calc(-50% + ${j.ky}px))`;
  };

  const touchAttackDown = (e) => { e.preventDefault(); engineRef.current?.setInput('attack', true); };
  const touchAttackUp = (e) => { e.preventDefault(); engineRef.current?.setInput('attack', false); };
  const touchSkill = (n) => (e) => {
    e.preventDefault();
    const eng = engineRef.current; if (!eng) return;
    if (n === 1) eng.useSkill1();
    if (n === 2) eng.useSkill2();
    if (n === 3) eng.useSkill3();
  };
  const touchInteract = (e) => { e.preventDefault(); engineRef.current?.tryInteract(); };

  const toggleMute = () => { ensureAudio(); const m = audio.toggleMute(); setMuted(m); };

  const hpPct = clamp((ui.hp / ui.hpMax) * 100, 0, 100);
  const xpPct = ((ui.kills % 5) / 5) * 100;

  return (
    <div className={`game-wrap ${touch ? 'touch-on' : ''}`} data-testid="game-wrap">
      <canvas
        ref={canvasRef}
        className="game-canvas"
        data-testid="game-canvas"
        onMouseDown={handleCanvasMouseDown}
        onMouseUp={handleCanvasMouseUp}
      />

      <button
        className="mute-btn"
        data-testid="mute-btn"
        onClick={toggleMute}
        title={muted ? 'Tirar do mudo (M)' : 'Mutar (M)'}
      >
        {muted ? '♪' : '♫'}
      </button>

      {screen === 'playing' && (
        <div className="hud" data-testid="hud">
          <div className="hud-top">
            <div className="hud-bars">
              <div className="bar hp" data-testid="hp-bar">
                <span style={{ width: `${hpPct}%` }} />
                <div className="bar-label">{Math.ceil(ui.hp)} / {Math.ceil(ui.hpMax)}</div>
              </div>
              <div className="bar xp" data-testid="xp-bar">
                <span style={{ width: `${xpPct}%` }} />
                <div className="bar-label">NV {ui.level}  •  {ui.kills} ABATES  •  {ui.className}</div>
              </div>
            </div>
            <div className="hud-panel" data-testid="phase-label">
              ANDAR {ui.phase} / {PHASES}
              <div style={{ fontSize: 14, color: '#c79262' }}>
                {ui.bossSpawned ? 'BELIAL DESPERTOU' : `${ui.enemiesLeft} DEMÔNIOS`}
              </div>
            </div>
            <div className="hud-panel" data-testid="stats-panel">
              ⚔ {Math.round(ui.damage)}<br/>
              ⚡ {ui.attackSpeed.toFixed(2)}/s<br/>
              ⛨ {Math.round(ui.defense)}<br/>
              ✚ {Math.round(ui.lifesteal * 100)}%
            </div>
          </div>

          <div className="skills" data-testid="skills">
            <SkillBox keyLabel="Q" ico="✸" name="Invul." cd={ui.invulnCd} active={ui.invulnTime} testid="skill-invuln" />
            <SkillBox keyLabel="R" ico="◯" name="Campo"  cd={ui.fieldCd}  active={ui.fieldTime} testid="skill-field" />
            <SkillBox keyLabel="F" ico="✧" name="Burst"  cd={ui.burstCd}  active={0}            testid="skill-burst" />
          </div>

          <div className="controls-hint">WASD MOVE  •  CLICK / ESPAÇO ATAQUE  •  Q R F SKILLS  •  E FALAR  •  M MUTAR</div>

          <div className="touch-controls">
            <div
              className="joystick"
              data-testid="joystick"
              onTouchStart={onJoyStart}
              onTouchMove={onJoyMove}
              onTouchEnd={onJoyEnd}
              onTouchCancel={onJoyEnd}
            >
              <div id="joy-knob" className="knob" />
            </div>
            <div className="touch-actions">
              <button className="touch-btn skill" data-testid="touch-skill-1" onTouchStart={touchSkill(1)}>
                <div className="ico">✸</div>
                <div className="lbl">INVUL</div>
                {ui.invulnCd > 0 && <div className="cd">{ui.invulnCd.toFixed(1)}</div>}
              </button>
              <button className="touch-btn skill" data-testid="touch-skill-2" onTouchStart={touchSkill(2)}>
                <div className="ico">◯</div>
                <div className="lbl">CAMPO</div>
                {ui.fieldCd > 0 && <div className="cd">{ui.fieldCd.toFixed(1)}</div>}
              </button>
              <button className="touch-btn skill" data-testid="touch-skill-3" onTouchStart={touchSkill(3)}>
                <div className="ico">✧</div>
                <div className="lbl">BURST</div>
                {ui.burstCd > 0 && <div className="cd">{ui.burstCd.toFixed(1)}</div>}
              </button>
              <button
                className="touch-btn attack"
                data-testid="touch-attack"
                onTouchStart={touchAttackDown}
                onTouchEnd={touchAttackUp}
                onTouchCancel={touchAttackUp}
              >
                <div className="ico">⚔</div>
                <div className="lbl">ATAQUE</div>
              </button>
            </div>
            <button
              className={`touch-interact ${nearNpc ? 'visible' : ''}`}
              data-testid="touch-interact"
              onTouchStart={touchInteract}
              onClick={touchInteract}
            >
              FALAR
            </button>
          </div>

          {ui.bossSpawned && engineRef.current?.bossBannerTime > 0 && (
            <div className="boss-banner">BELIAL</div>
          )}
        </div>
      )}

      {screen === 'menu' && (
        <div className="screen" data-testid="menu-screen">
          <h1 className="title">INFERNO</h1>
          <div className="subtitle">O CAÇADOR DESCE</div>
          <div className="lore">
            Sem nome. Sem rosto. Sem emoções.<br/>
            Uma entidade firmada num pacto antigo<br/>
            que persegue os demônios até o último eco.<br/>
            <span style={{ color: '#ff5028' }}>Belial</span> aguarda, dez andares abaixo.
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
            {savedRun && savedRun.current && (
              <button className="menu-btn" onClick={continueRun} data-testid="continue-btn">
                CONTINUAR (ANDAR {savedRun.current.phase})
              </button>
            )}
            <button className="menu-btn" onClick={startGame} data-testid="start-btn">
              {savedRun && savedRun.current ? 'NOVA DESCIDA' : 'COMEÇAR DESCIDA'}
            </button>
          </div>
          {savedRun && savedRun.best && (
            <div style={{ marginTop: 18, fontSize: 16, color: '#8a6040', letterSpacing: 2 }}>
              MELHOR PROFUNDIDADE: ANDAR {savedRun.best.phase}  •  {savedRun.best.kills} ABATES
              <button
                className="menu-btn"
                style={{ marginLeft: 14, fontSize: 12, padding: '4px 10px' }}
                onClick={wipeSave}
                data-testid="wipe-save-btn"
              >
                APAGAR SAVE
              </button>
            </div>
          )}
        </div>
      )}

      {screen === 'lore' && (
        <div className="screen lore-screen" data-testid="lore-screen">
          <div className="lore-header">— FRAGMENTO ANTERIOR AO TEMPO —</div>
          <h2 className="lore-title">O CAÇADOR</h2>
          <div className="lore-scroll" data-testid="lore-scroll">
            <p>
              Antes do tempo, quando o véu entre os mundos ainda era pele,
              um homem — ou o que um dia foi homem — firmou um pacto com algo
              mais antigo que os deuses.
            </p>
            <p className="pact">Cedeu o <i>nome</i>, para que nenhum demônio pudesse invocá-lo.</p>
            <p className="pact">Cedeu o <i>rosto</i>, para que nenhum espelho o reconhecesse.</p>
            <p className="pact">Cedeu as <i>emoções</i>, para que medo, dor ou piedade nunca atrasassem o golpe.</p>
            <p>O que sobrou já não é humano. Já não está vivo. Mas também nunca morreu.</p>
            <p>
              É apenas uma <b>função</b>. Um recipiente.
              Ódio infinito destilado num único propósito: encontrá-los,
              apagá-los, persegui-los por cada camada da escuridão
              até que não reste sequer o eco.
            </p>
            <p>
              Cada criança devorada é uma linha rompida.
              Cada alma roubada, uma dívida que cresce.
              E alguém precisa cobrar essa dívida.
            </p>
            <p>
              Ele não lembra por que começou. Não sabe se haverá fim.
              O pacto diz apenas:
              <span className="climax"> &nbsp;enquanto um demônio caminhar pelo mundo, o Caçador também caminha.</span>
            </p>
            <p>
              Atravessa pesadelos como se fossem corredores.
              Mata como respira.
              Não grita. Não treme. Não comemora.
              <br/>Apenas <b>desce</b>.
            </p>
            <p>
              Hoje, o rastro o trouxe ao próprio Inferno —
              dez andares, dez hordas, e no fundo:
              <span style={{ color: '#ff5028' }}> Belial</span>,
              o arquidemônio que rasgou o pacto original e soltou os outros sobre o mundo.
            </p>
            <p className="climax" style={{ textAlign: 'center', marginTop: 28 }}>
              A entidade sem nome, sem rosto, sem emoção,<br/>
              respira fundo apenas porque o corpo ainda lembra como se respira.<br/>
              E entra.
            </p>
          </div>
          <div className="lore-actions">
            <button className="menu-btn" onClick={() => goBack('menu')} data-testid="lore-back-btn">VOLTAR</button>
            <button className="menu-btn" onClick={goClass} data-testid="lore-continue-btn">PROSSEGUIR</button>
          </div>
        </div>
      )}

      {screen === 'class' && (
        <div className="screen" data-testid="class-screen">
          <h2 className="title" style={{ fontSize: '54px' }}>ESCOLHA SEU CAMINHO</h2>
          <div className="subtitle">QUE FORMA SUA ALMA ASSUMIU?</div>
          <div className="class-grid" data-testid="class-grid">
            {Object.values(CLASSES).map(c => (
              <div
                key={c.id}
                className={`class-card ${selectedClass === c.id ? 'selected' : ''}`}
                data-testid={`class-${c.id}`}
                onClick={() => { audio.play('click'); setSelectedClass(c.id); }}
                onDoubleClick={() => beginRun(c.id)}
              >
                <div className="class-name" style={{ color: c.color }}>{c.name}</div>
                <div className="class-tag">{c.tagline}</div>
                <div className="class-desc">{c.description}</div>
                <ul className="class-passives">
                  {c.passives.map((p, i) => <li key={i}>{p}</li>)}
                </ul>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 24 }}>
            <button className="menu-btn" onClick={() => goBack('lore')} data-testid="back-btn">VOLTAR</button>
            <button className="menu-btn" onClick={() => beginRun(selectedClass)} data-testid="confirm-class-btn">
              DESCER COMO {CLASSES[selectedClass].name}
            </button>
          </div>
        </div>
      )}

      {screen === 'attr' && (
        <div className="screen" data-testid="attr-screen">
          <h2 className="title" style={{ fontSize: '54px' }}>ANDAR {ui.phase} VENCIDO</h2>
          <div className="subtitle">ESCOLHA UMA DÁDIVA SOMBRIA</div>
          <div className="attr-grid">
            {ATTRS.map(a => (
              <div key={a.key} className="attr-card" data-testid={`attr-${a.key}`} onClick={() => pickAttr(a.key)}>
                <div className="ico">{a.ico}</div>
                <div className="name">{a.name}</div>
                <div className="val">{a.val}</div>
                <div className="desc">{a.desc}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {screen === 'npc' && (
        <div className="screen" data-testid="npc-screen">
          <div className="dialog-box">
            <div className="speaker">ALMA PERDIDA</div>
            <div>{NPC_LINES[npcLineIdx]}</div>
          </div>
          {npcLineIdx === NPC_LINES.length - 1 && !npcBuffed && (
            <button className="menu-btn" onClick={acceptNpcBuff} data-testid="npc-accept-btn">ACEITAR BÊNÇÃO (+3% Vamp. e cura total)</button>
          )}
          <button className="menu-btn" onClick={advanceNpc} data-testid="npc-next-btn">
            {npcLineIdx < NPC_LINES.length - 1 ? 'CONTINUAR' : (npcBuffed ? 'SEGUIR EM FRENTE' : 'DEIXAR PARA TRÁS')}
          </button>
        </div>
      )}

      {screen === 'dead' && (
        <div className="screen" data-testid="dead-screen">
          <h2 className="title" style={{ color: 'transparent', WebkitTextStroke: '1px #ff2020' }}>VOCÊ TOMBOU</h2>
          <div className="subtitle">No andar {ui.phase}, com {ui.kills} abates.</div>
          <button className="menu-btn" onClick={() => setScreen('class')} data-testid="restart-btn">TENTAR DE NOVO</button>
        </div>
      )}

      {screen === 'victory' && (
        <div className="screen" data-testid="victory-screen">
          <h2 className="title">BELIAL CAIU</h2>
          <div className="subtitle">O CAÇADOR DESCEU. E VOLTOU.</div>
          <div className="lore">
            O grande demônio desfaz-se em cinzas. As camadas tremem.<br/>
            A entidade cruza o portal que jamais deveria ter existido.<br/>
            E ainda assim, lá em cima... a noite continua eterna.
          </div>
          <button className="menu-btn" onClick={() => setScreen('class')} data-testid="play-again-btn">JOGAR NOVAMENTE</button>
        </div>
      )}
    </div>
  );
}

function SkillBox({ keyLabel, ico, name, cd, active, testid }) {
  return (
    <div className={`skill ${cd <= 0 ? 'ready' : ''}`} data-testid={testid}>
      <div className="key">{keyLabel}</div>
      <div className="icon">{ico}</div>
      <div style={{ fontSize: 11, color: '#c79262' }}>{name}</div>
      {active > 0 && <div className="cd" style={{ background: 'rgba(80,150,255,0.5)' }}>{active.toFixed(1)}</div>}
      {active <= 0 && cd > 0 && <div className="cd">{cd.toFixed(1)}</div>}
    </div>
  );
}

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
