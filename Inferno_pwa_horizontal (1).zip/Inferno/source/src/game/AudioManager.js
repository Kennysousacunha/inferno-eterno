// AudioManager - procedural dark ambient music + SFX using Web Audio API.
// No external assets. Designed to be initialized on the first user gesture.

export class AudioManager {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.musicNodes = [];
    this.musicPlaying = false;
    this.muted = false;
    this.musicVol = 0.45;
    this.sfxVol = 0.65;
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 1.0;
    this.master.connect(this.ctx.destination);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = this.musicVol;
    this.musicGain.connect(this.master);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = this.sfxVol;
    this.sfxGain.connect(this.master);
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.setValueAtTime(m ? 0 : 1.0, this.ctx.currentTime);
  }
  toggleMute() { this.setMuted(!this.muted); return this.muted; }

  // ===== MUSIC =====
  // Dark ambient drone using detuned oscillators + slow filter modulation + occasional bell tones.
  startMusic(scene = 'menu') {
    if (!this.ctx) return;
    this.stopMusic();
    this.musicPlaying = true;
    const t = this.ctx.currentTime;
    const out = this.musicGain;

    // Filter that opens/closes slowly
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = scene === 'boss' ? 480 : 380;
    filter.Q.value = 4;
    filter.connect(out);

    // 3 drone voices: root, fifth, minor third — dark minor chord
    // Base frequencies (very low, sub-bass to mid)
    const base = scene === 'boss' ? 41.2 : 49; // G1 or E1
    const freqs = [base, base * 1.5, base * (Math.pow(2, 3/12))]; // root, fifth, minor-3rd
    for (const f of freqs) {
      const o1 = this.ctx.createOscillator();
      const o2 = this.ctx.createOscillator();
      o1.type = 'sawtooth'; o2.type = 'sawtooth';
      o1.frequency.value = f;
      o2.frequency.value = f * 1.005; // detune for shimmer
      const g = this.ctx.createGain();
      g.gain.value = 0;
      g.gain.linearRampToValueAtTime(0.18, t + 4); // slow fade in
      o1.connect(g); o2.connect(g);
      g.connect(filter);
      o1.start(t); o2.start(t);
      this.musicNodes.push(o1, o2, g);
    }

    // Sub bass pulse
    const sub = this.ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.value = base / 2;
    const subG = this.ctx.createGain();
    subG.gain.value = 0;
    sub.connect(subG); subG.connect(out);
    sub.start(t);
    // LFO on sub for slow swells every ~8s
    const lfo = this.ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.125; // every 8s
    const lfoG = this.ctx.createGain();
    lfoG.gain.value = 0.10;
    lfo.connect(lfoG); lfoG.connect(subG.gain);
    subG.gain.value = 0.12;
    lfo.start(t);
    this.musicNodes.push(sub, subG, lfo, lfoG, filter);

    // Wind noise layer - quiet, eerie
    const noiseBuf = this._noiseBuffer(2);
    const noiseSrc = this.ctx.createBufferSource();
    noiseSrc.buffer = noiseBuf; noiseSrc.loop = true;
    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass'; noiseFilter.frequency.value = 600; noiseFilter.Q.value = 0.8;
    const noiseG = this.ctx.createGain();
    noiseG.gain.value = 0;
    noiseG.gain.linearRampToValueAtTime(0.045, t + 5);
    noiseSrc.connect(noiseFilter); noiseFilter.connect(noiseG); noiseG.connect(out);
    noiseSrc.start(t);
    this.musicNodes.push(noiseSrc, noiseFilter, noiseG);

    // Occasional bell drone (every 6-10s)
    this._bellTimer = this._scheduleBells(scene);
  }

  _scheduleBells(scene) {
    const playBell = () => {
      if (!this.musicPlaying || !this.ctx) return;
      const t = this.ctx.currentTime;
      const o = this.ctx.createOscillator();
      o.type = 'triangle';
      // dissonant notes
      const notes = scene === 'boss'
        ? [110, 116.5, 138.6]
        : [196, 220, 233, 261.6];
      const f = notes[Math.floor(Math.random() * notes.length)];
      o.frequency.value = f * (0.5 + Math.floor(Math.random() * 2) * 0.5);
      const g = this.ctx.createGain();
      g.gain.value = 0;
      g.gain.linearRampToValueAtTime(0.10, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.001, t + 4);
      o.connect(g); g.connect(this.musicGain);
      o.start(t); o.stop(t + 4.2);
      const next = 4000 + Math.random() * 5000;
      this._bellTimer = setTimeout(playBell, next);
    };
    return setTimeout(playBell, 3000 + Math.random() * 3000);
  }

  stopMusic() {
    this.musicPlaying = false;
    if (this._bellTimer) { clearTimeout(this._bellTimer); this._bellTimer = null; }
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    for (const n of this.musicNodes) {
      try {
        if (n.stop) {
          // fade gain into stop
          if (n.gain) n.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
          n.stop(t + 0.5);
        } else if (n.gain && n.gain.setValueAtTime) {
          n.gain.linearRampToValueAtTime(0, t + 0.4);
        }
      } catch (_err) { /* node already stopped */ }
    }
    this.musicNodes = [];
  }

  // Helper: create noise buffer
  _noiseBuffer(seconds = 2) {
    const sr = this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, sr * seconds, sr);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    return buf;
  }

  // ===== SFX =====
  play(type) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    switch (type) {
      case 'attack': this._sfxAttack(t); break;
      case 'hit':    this._sfxHit(t);    break;
      case 'hurt':   this._sfxHurt(t);   break;
      case 'death':  this._sfxDeath(t);  break;
      case 'kill':   this._sfxKill(t);   break;
      case 'skill1': this._sfxInvuln(t); break;
      case 'skill2': this._sfxField(t);  break;
      case 'skill3': this._sfxBurst(t);  break;
      case 'level':  this._sfxLevel(t);  break;
      case 'boss':   this._sfxBoss(t);   break;
      case 'victory':this._sfxVictory(t);break;
      case 'click':  this._sfxClick(t);  break;
      case 'dodge':  this._sfxDodge(t);  break;
      default: break;
    }
  }

  _tone(t, freq, dur, type = 'sine', vol = 0.3, attack = 0.005, glideTo = null) {
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (glideTo != null) o.frequency.exponentialRampToValueAtTime(Math.max(1, glideTo), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.sfxGain);
    o.start(t); o.stop(t + dur + 0.05);
    return { o, g };
  }

  _noise(t, dur, vol = 0.3, filterFreq = 1200, filterType = 'lowpass', q = 1) {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(Math.max(0.2, dur + 0.05));
    const f = this.ctx.createBiquadFilter();
    f.type = filterType; f.frequency.value = filterFreq; f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.sfxGain);
    src.start(t); src.stop(t + dur + 0.05);
    return { src, f, g };
  }

  _sfxAttack(t) {
    // sword whoosh: filtered noise sweep + short high tone
    const n = this._noise(t, 0.18, 0.35, 4000, 'bandpass', 2);
    n.f.frequency.setValueAtTime(4000, t);
    n.f.frequency.exponentialRampToValueAtTime(800, t + 0.18);
    this._tone(t, 1200, 0.08, 'square', 0.08, 0.005, 600);
  }

  _sfxHit(t) {
    // enemy hit: punchy mid thud + crunch noise
    this._tone(t, 220, 0.12, 'sawtooth', 0.22, 0.003, 90);
    this._noise(t, 0.08, 0.18, 1200, 'lowpass', 0.7);
  }

  _sfxHurt(t) {
    // player hurt: harsh low buzz
    this._tone(t, 110, 0.18, 'square', 0.22, 0.003, 60);
    this._noise(t, 0.12, 0.25, 700, 'bandpass', 0.5);
  }

  _sfxKill(t) {
    // satisfying kill: crunch + falling tone
    this._noise(t, 0.18, 0.3, 1800, 'lowpass', 1);
    this._tone(t, 330, 0.22, 'triangle', 0.18, 0.005, 80);
  }

  _sfxDeath(t) {
    // player death: long descending growl
    this._tone(t, 220, 1.4, 'sawtooth', 0.28, 0.02, 40);
    this._tone(t + 0.05, 110, 1.4, 'sawtooth', 0.20, 0.02, 25);
    this._noise(t, 1.0, 0.18, 500, 'lowpass', 1);
  }

  _sfxInvuln(t) {
    // rising ethereal tone
    this._tone(t, 440, 0.5, 'sine', 0.20, 0.01, 1320);
    this._tone(t + 0.03, 660, 0.5, 'triangle', 0.12, 0.01, 1980);
  }

  _sfxField(t) {
    // pulsing field activation
    this._tone(t, 220, 0.6, 'square', 0.16, 0.005, 660);
    this._tone(t + 0.05, 440, 0.5, 'sawtooth', 0.10, 0.005, 880);
  }

  _sfxBurst(t) {
    // big explosive burst
    this._noise(t, 0.4, 0.45, 1500, 'lowpass', 1);
    this._tone(t, 880, 0.3, 'sawtooth', 0.18, 0.003, 110);
    this._tone(t + 0.02, 1320, 0.25, 'square', 0.12, 0.003, 220);
  }

  _sfxLevel(t) {
    // ascending arpeggio
    const notes = [392, 523, 659, 880];
    notes.forEach((n, i) => this._tone(t + i * 0.08, n, 0.25, 'triangle', 0.20));
  }

  _sfxBoss(t) {
    // deep menacing roar
    this._tone(t, 80, 2.0, 'sawtooth', 0.35, 0.05, 40);
    this._tone(t + 0.1, 55, 2.0, 'square', 0.25, 0.05, 30);
    this._noise(t, 1.8, 0.3, 400, 'lowpass', 1);
  }

  _sfxVictory(t) {
    // triumphant minor->major resolution
    const notes = [261.6, 329.6, 392, 523, 659];
    notes.forEach((n, i) => this._tone(t + i * 0.15, n, 0.45, 'sine', 0.22, 0.02));
  }

  _sfxClick(t) {
    this._tone(t, 660, 0.04, 'square', 0.08, 0.002, 440);
  }

  _sfxDodge(t) {
    // whoosh up
    this._noise(t, 0.18, 0.22, 3000, 'bandpass', 2);
    this._tone(t, 660, 0.12, 'triangle', 0.10, 0.003, 1320);
  }
}

// singleton
export const audio = new AudioManager();
