// Save/Load system - persists best run progress to localStorage.

const KEY = 'inferno_save_v1';

export function loadSave() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') return null;
    return data;
  } catch (_e) {
    return null;
  }
}

export function saveProgress(snapshot) {
  // snapshot: { phase, kills, level, classId, attrs, hp, hpMax, damage, attackSpeed, defense, lifesteal, npcBuffed }
  try {
    const existing = loadSave() || { best: {}, current: null };
    existing.current = { ...snapshot, ts: Date.now() };
    // best by deepest phase reached
    const bestPhase = (existing.best && existing.best.phase) || 0;
    if (snapshot.phase >= bestPhase) {
      existing.best = { phase: snapshot.phase, kills: snapshot.kills, classId: snapshot.classId, ts: Date.now() };
    }
    localStorage.setItem(KEY, JSON.stringify(existing));
  } catch (_e) { /* storage might be unavailable */ }
}

export function clearCurrentSave() {
  try {
    const existing = loadSave();
    if (!existing) return;
    existing.current = null;
    localStorage.setItem(KEY, JSON.stringify(existing));
  } catch (_e) { /* ignore */ }
}

export function clearAllSave() {
  try { localStorage.removeItem(KEY); } catch (_e) { /* ignore */ }
}
