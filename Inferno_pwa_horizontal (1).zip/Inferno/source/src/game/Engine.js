// Core engine for "INFERNO" - top-down action roguelite with labyrinth dungeons.
import {
  W, H, PHASES, BASE, LEVEL_BONUS, SPR,
  ENEMY_TYPES, BOSS, PHASE_SPAWNS, phaseScale, CLASSES,
  clamp, dist, angle, rand,
} from './config';
import { audio } from './AudioManager';
import { saveProgress, clearCurrentSave } from './Save';

export class Engine {
  constructor(opts = {}) {
    this.onPhaseClear = opts.onPhaseClear || (() => {});
    this.onDeath = opts.onDeath || (() => {});
    this.onVictory = opts.onVictory || (() => {});
    this.onMeetNpc = opts.onMeetNpc || (() => {});
    this.onUiUpdate = opts.onUiUpdate || (() => {});
    this.spriteImg = null;
    this.walls = [];
    this.reset();
  }

  bindSprite(img) { this.spriteImg = img; }

  reset(classId = 'vampire') {
    const cls = CLASSES[classId] || CLASSES.vampire;
    const b = cls.bonuses || {};
    const hpMax = Math.round(BASE.hp * (b.hpMul || 1));

    this.player = {
      x: W / 2, y: H / 2, r: 16,
      facing: 0, moving: false,
      animTime: 0, animFrame: 0,
      attackAnim: 0, flipX: false,

      classId: cls.id,
      classColor: cls.color,
      className: cls.name,
      dodgeChance: b.dodgeChance || 0,
      regenPerSec: b.regenPerSec || 0,

      hp: hpMax, hpMax,
      damage: BASE.damage * (b.damageMul || 1),
      attackSpeed: BASE.attackSpeed * (b.attackSpeedMul || 1),
      defense: BASE.defense * (b.defenseMul || 1),
      lifesteal: BASE.lifesteal + (b.lifestealAdd || 0),
      moveSpeed: BASE.moveSpeed * (b.moveSpeedMul || 1),
      attackRange: BASE.attackRange,

      attackCooldown: 0,
      kills: 0,
      level: 1,

      invulnTime: 0, invulnCd: 0,
      fieldTime: 0,  fieldCd: 0,
      burstCd: 0,

      hurtFlash: 0,
      dead: false,
    };

    this.enemies = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];
    this.npcs = [];
    this.walls = [];
    this.phase = 1;
    this.phaseTime = 0;
    this.cleared = false;
    this.bossSpawned = false;
    this.bossBannerTime = 0;
    this.shake = 0;
    this.input = { up:false, down:false, left:false, right:false, attack:false, skill1:false, skill2:false, skill3:false, interact:false };

    this.startPhase(1);
    this.emitUi();
  }

  emitUi() {
    const p = this.player;
    this.onUiUpdate({
      hp: p.hp, hpMax: p.hpMax,
      damage: p.damage, attackSpeed: p.attackSpeed,
      defense: p.defense, lifesteal: p.lifesteal,
      level: p.level, kills: p.kills,
      phase: this.phase,
      classId: p.classId, classColor: p.classColor, className: p.className,
      dodgeChance: p.dodgeChance,
      invulnCd: p.invulnCd, fieldCd: p.fieldCd, burstCd: p.burstCd,
      invulnTime: p.invulnTime, fieldTime: p.fieldTime,
      enemiesLeft: this.enemies.length,
      bossSpawned: this.bossSpawned,
      cleared: this.cleared,
      dead: p.dead,
    });
  }

  // ===== PHASE / MAP =====
  startPhase(n) {
    this.phase = n;
    this.phaseTime = 0;
    this.cleared = false;
    this.bossSpawned = false;
    this.enemies = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];
    this.npcs = [];
    this.walls = [];

    // generate map
    if (n === 10) this.generateBossArena();
    else this.generateLabyrinth(n);

    // place player at an open cell on the left side
    const sp = this.findOpenSpawn(W * 0.12, H * 0.5, this.player.r + 2);
    this.player.x = sp.x; this.player.y = sp.y;

    const spawnCfg = PHASE_SPAWNS[n - 1];
    if (spawnCfg.boss) {
      this.spawnBoss();
      this.bossSpawned = true;
      this.bossBannerTime = 3;
      audio.play('boss');
    } else {
      const scale = phaseScale(n);
      for (let i = 0; i < spawnCfg.count; i++) {
        const type = spawnCfg.types[i % spawnCfg.types.length];
        this.spawnEnemy(type, scale);
      }
    }

    // Floor 2 NPC: Alma Perdida (always to the right of player, in an open spot)
    if (n === 2) {
      const np = this.findOpenSpawn(W * 0.72, H * 0.5, 22);
      this.npcs.push({ x: np.x, y: np.y, r: 18, name: 'Alma Perdida', interacted: false, bobT: 0 });
    }

    this.emitUi();
  }

  generateLabyrinth(phase) {
    const cellSize = 80;
    const cols = Math.floor(W / cellSize);
    const rows = Math.floor(H / cellSize);
    const grid = Array.from({ length: rows }, () => Array(cols).fill(0));
    const maxDepth = Math.min(6, 3 + Math.floor(phase / 2));

    const divide = (x, y, w, h, depth) => {
      if (depth > maxDepth) return;
      if (w < 3 && h < 3) return;
      const horizontal = h > w + 1 ? true : (w > h + 1 ? false : Math.random() < 0.5);
      if (horizontal) {
        if (h < 3) return;
        const wy = y + 1 + Math.floor(Math.random() * (h - 2));
        const gaps = new Set([x + Math.floor(Math.random() * w)]);
        if (phase < 6 && w > 4) gaps.add(x + Math.floor(Math.random() * w));
        for (let i = x; i < x + w; i++) if (!gaps.has(i)) grid[wy][i] = 1;
        divide(x, y, w, wy - y, depth + 1);
        divide(x, wy + 1, w, y + h - (wy + 1), depth + 1);
      } else {
        if (w < 3) return;
        const wx = x + 1 + Math.floor(Math.random() * (w - 2));
        const gaps = new Set([y + Math.floor(Math.random() * h)]);
        if (phase < 6 && h > 4) gaps.add(y + Math.floor(Math.random() * h));
        for (let i = y; i < y + h; i++) if (!gaps.has(i)) grid[i][wx] = 1;
        divide(x, y, wx - x, h, depth + 1);
        divide(wx + 1, y, x + w - (wx + 1), h, depth + 1);
      }
    };
    divide(0, 0, cols, rows, 0);

    // Knock out some random walls to ensure connectivity in feel
    const holes = Math.max(3, 9 - Math.floor(phase / 2));
    for (let i = 0; i < holes; i++) {
      grid[Math.floor(Math.random() * rows)][Math.floor(Math.random() * cols)] = 0;
    }

    // Merge horizontal runs to fewer rectangles
    const used = Array.from({ length: rows }, () => Array(cols).fill(false));
    this.walls = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r][c] === 1 && !used[r][c]) {
          let len = 1;
          while (c + len < cols && grid[r][c + len] === 1 && !used[r][c + len]) len++;
          for (let k = 0; k < len; k++) used[r][c + k] = true;
          this.walls.push({ x: c * cellSize, y: r * cellSize, w: len * cellSize, h: cellSize });
        }
      }
    }
    // Outer walls
    const b = 14;
    this.walls.push({ x: 0, y: 0, w: W, h: b });
    this.walls.push({ x: 0, y: H - b, w: W, h: b });
    this.walls.push({ x: 0, y: 0, w: b, h: H });
    this.walls.push({ x: W - b, y: 0, w: b, h: H });
  }

  generateBossArena() {
    this.walls = [];
    const b = 16;
    this.walls.push({ x: 0, y: 0, w: W, h: b });
    this.walls.push({ x: 0, y: H - b, w: W, h: b });
    this.walls.push({ x: 0, y: 0, w: b, h: H });
    this.walls.push({ x: W - b, y: 0, w: b, h: H });
    // decorative pillars
    const pillars = [
      { x: W * 0.22, y: H * 0.22 },
      { x: W * 0.78, y: H * 0.22 },
      { x: W * 0.22, y: H * 0.78 },
      { x: W * 0.78, y: H * 0.78 },
    ];
    for (const p of pillars) this.walls.push({ x: p.x - 30, y: p.y - 30, w: 60, h: 60 });
  }

  // Find open position near (cx, cy) using spiral
  findOpenSpawn(cx, cy, r = 18) {
    if (!this.collideCircleWithWalls(cx, cy, r)) return { x: cx, y: cy };
    for (let radius = 30; radius < 600; radius += 30) {
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 12) {
        const x = cx + Math.cos(a) * radius;
        const y = cy + Math.sin(a) * radius;
        if (x < 30 || x > W - 30 || y < 30 || y > H - 30) continue;
        if (!this.collideCircleWithWalls(x, y, r)) return { x, y };
      }
    }
    return { x: cx, y: cy };
  }

  collideCircleWithWalls(cx, cy, r) {
    for (const w of this.walls) {
      const nx = Math.max(w.x, Math.min(cx, w.x + w.w));
      const ny = Math.max(w.y, Math.min(cy, w.y + w.h));
      const dx = cx - nx, dy = cy - ny;
      if (dx * dx + dy * dy < r * r) return w;
    }
    return null;
  }

  moveWithCollision(entity, dx, dy, r) {
    entity.x += dx;
    let hit = this.collideCircleWithWalls(entity.x, entity.y, r);
    if (hit) {
      if (dx > 0) entity.x = hit.x - r - 0.5;
      else if (dx < 0) entity.x = hit.x + hit.w + r + 0.5;
    }
    entity.y += dy;
    hit = this.collideCircleWithWalls(entity.x, entity.y, r);
    if (hit) {
      if (dy > 0) entity.y = hit.y - r - 0.5;
      else if (dy < 0) entity.y = hit.y + hit.h + r + 0.5;
    }
  }

  // ===== SPAWN =====
  spawnEnemy(typeKey, scale) {
    const t = ENEMY_TYPES[typeKey];
    const p = this.player;
    let pos = null;
    for (let tries = 0; tries < 40; tries++) {
      const cx = rand(60, W - 60);
      const cy = rand(60, H - 60);
      if (dist({ x: cx, y: cy }, p) < 200) continue;
      if (!this.collideCircleWithWalls(cx, cy, t.radius + 2)) { pos = { x: cx, y: cy }; break; }
    }
    if (!pos) pos = this.findOpenSpawn(rand(60, W - 60), rand(60, H - 60), t.radius + 2);
    this.enemies.push({
      type: typeKey, ...t,
      x: pos.x, y: pos.y,
      hp: Math.round(t.hp * scale.hpMul),
      hpMax: Math.round(t.hp * scale.hpMul),
      damage: t.damage * scale.dmgMul,
      atkTimer: rand(0, t.attackCooldown),
      stateTimer: 0,
      stateData: {},
      animT: Math.random() * 10,
    });
  }

  spawnBoss() {
    const scale = phaseScale(10);
    const bp = this.findOpenSpawn(W * 0.78, H * 0.5, BOSS.radius);
    this.enemies.push({
      type: 'boss', isBoss: true,
      name: BOSS.name,
      color: BOSS.color, eye: BOSS.eye, radius: BOSS.radius, r: BOSS.radius,
      x: bp.x, y: bp.y,
      hp: BOSS.hp * scale.hpMul, hpMax: BOSS.hp * scale.hpMul,
      damage: BOSS.damage * scale.dmgMul,
      speed: BOSS.speed,
      atkTimer: 1.5,
      patternTimer: 0,
      patternState: 'idle',
      stateData: {},
      animT: 0,
      xpReward: 50,
      behavior: 'boss',
      attackRange: 70,
      attackCooldown: 2.0,
    });
  }

  setInput(key, value) { this.input[key] = value; }

  damagePlayer(amount) {
    const p = this.player;
    if (p.dead || p.invulnTime > 0) return;
    if (p.dodgeChance > 0 && Math.random() < p.dodgeChance) {
      this.floatTexts.push({ x: p.x, y: p.y - 20, t: 0.8, text: 'ESQUIVOU', color: '#a0e0ff' });
      for (let i = 0; i < 6; i++) {
        this.particles.push({ x: p.x, y: p.y, vx: rand(-80, 80), vy: rand(-120, -20), t: 0.5, life: 0.5, color: '#80c0ff', size: 2 });
      }
      audio.play('dodge');
      return;
    }
    const dr = clamp(p.defense / (p.defense + 100), 0, 0.75);
    const dmg = Math.max(1, amount * (1 - dr));
    p.hp -= dmg;
    p.hurtFlash = 0.25;
    this.shake = Math.min(this.shake + 6, 14);
    this.floatTexts.push({ x: p.x, y: p.y - 20, t: 0.8, text: `-${Math.round(dmg)}`, color: '#ff5040' });
    audio.play('hurt');
    if (p.hp <= 0) {
      p.hp = 0; p.dead = true; audio.play('death');
      clearCurrentSave();
      this.onDeath();
    }
    this.emitUi();
  }

  damageEnemy(e, amount, fromPlayer = true) {
    e.hp -= amount;
    this.floatTexts.push({ x: e.x, y: e.y - e.radius - 6, t: 0.6, text: `${Math.round(amount)}`, color: '#ffe070' });
    for (let i = 0; i < 5; i++) {
      this.particles.push({ x: e.x, y: e.y, vx: rand(-80,80), vy: rand(-80,80), t: 0.5, life: 0.5, color: '#a01010', size: rand(2,4) });
    }
    if (e.hp <= 0) { this.killEnemy(e, fromPlayer); audio.play('kill'); return true; }
    if (fromPlayer) audio.play('hit');
    return false;
  }

  killEnemy(e, fromPlayer) {
    e.dead = true;
    for (let i = 0; i < 14; i++) {
      this.particles.push({ x: e.x, y: e.y, vx: rand(-160,160), vy: rand(-160,160), t: 0.8, life: 0.8, color: '#601010', size: rand(2,5) });
    }
    if (fromPlayer) {
      const p = this.player;
      p.kills++;
      if (p.kills % 5 === 0) {
        p.level++;
        p.damage *= 1 + LEVEL_BONUS;
        p.attackSpeed *= 1 + LEVEL_BONUS;
        p.defense *= 1 + LEVEL_BONUS;
        p.hpMax = Math.round(p.hpMax * (1 + LEVEL_BONUS));
        p.hp = Math.min(p.hpMax, p.hp + p.hpMax * LEVEL_BONUS);
        this.floatTexts.push({ x: p.x, y: p.y - 40, t: 1.4, text: `LEVEL ${p.level}`, color: '#ffd060' });
        audio.play('level');
        for (let i = 0; i < 24; i++) {
          this.particles.push({ x: p.x, y: p.y, vx: rand(-200,200), vy: rand(-260,-60), t: 0.9, life: 0.9, color: '#ffb040', size: rand(2,4) });
        }
      }
    }
  }

  // ===== SKILLS =====
  useSkill1() {
    const p = this.player;
    if (p.invulnCd > 0 || p.dead) return;
    p.invulnTime = 5; p.invulnCd = 10;
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 1, text: 'INVULNERÁVEL', color: '#80c0ff' });
    audio.play('skill1');
  }
  useSkill2() {
    const p = this.player;
    if (p.fieldCd > 0 || p.dead) return;
    p.fieldTime = 3; p.fieldCd = 10;
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 1, text: 'CAMPO DE FORÇA', color: '#ff80a0' });
    audio.play('skill2');
  }
  useSkill3() {
    const p = this.player;
    if (p.burstCd > 0 || p.dead) return;
    p.burstCd = 10;
    const N = 16;
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2;
      this.projectiles.push({
        x: p.x, y: p.y, vx: Math.cos(a) * 520, vy: Math.sin(a) * 520,
        r: 8, damage: p.damage * 0.85, life: 1.0, t: 1.0,
        from: 'player', color: '#ff7030',
      });
    }
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 1, text: 'DISPARO ARCANO', color: '#ff9050' });
    audio.play('skill3');
  }

  applyAttribute(key) {
    const p = this.player;
    switch (key) {
      case 'damage': p.damage *= 1.15; break;
      case 'attackSpeed': p.attackSpeed *= 1.20; break;
      case 'lifesteal': p.lifesteal += 0.10; break;
      case 'defense': p.defense *= 1.25; break;
      case 'hp': p.hpMax *= 2; p.hp = p.hpMax; break;
      default: break;
    }
    this.emitUi();
  }

  applyNpcBuff() {
    const p = this.player;
    p.hp = p.hpMax;
    p.lifesteal += 0.03;
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 2, text: 'ALMA TE ABENÇOOU', color: '#a0e0ff' });
    this.emitUi();
  }

  nextPhase() { if (this.phase < PHASES) this.startPhase(this.phase + 1); }

  tryInteract() {
    if (!this.npcs.length) return;
    const p = this.player;
    for (const npc of this.npcs) {
      if (dist(npc, p) < 60) { this.onMeetNpc(npc); return; }
    }
  }

  // ===== UPDATE =====
  update(dt) {
    if (this.player.dead) {
      this.updateParticles(dt);
      this.updateFloatTexts(dt);
      return;
    }
    this.phaseTime += dt;
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 24);
    if (this.bossBannerTime > 0) this.bossBannerTime -= dt;

    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateProjectiles(dt);
    this.updateParticles(dt);
    this.updateFloatTexts(dt);
    this.checkClear();
    this._uiT = (this._uiT || 0) + dt;
    if (this._uiT > 0.1) { this._uiT = 0; this.emitUi(); }
  }

  updatePlayer(dt) {
    const p = this.player;
    const inp = this.input;
    let dx = 0, dy = 0;
    if (inp.up) dy -= 1;
    if (inp.down) dy += 1;
    if (inp.left) dx -= 1;
    if (inp.right) dx += 1;
    const mag = Math.hypot(dx, dy);
    p.moving = mag > 0;
    if (p.moving) {
      dx /= mag; dy /= mag;
      this.moveWithCollision(p, dx * p.moveSpeed * dt, dy * p.moveSpeed * dt, p.r);
      p.facing = Math.atan2(dy, dx);
      if (Math.abs(dx) > 0.01) p.flipX = dx < 0;
      p.animTime += dt;
      if (p.animTime > 0.12) { p.animTime = 0; p.animFrame = (p.animFrame + 1) % SPR.walk.length; }
    } else {
      p.animTime += dt;
      if (p.animTime > 0.4) { p.animTime = 0; p.animFrame = (p.animFrame + 1) % SPR.idle.length; }
    }

    p.attackCooldown = Math.max(0, p.attackCooldown - dt);
    p.invulnCd = Math.max(0, p.invulnCd - dt);
    p.fieldCd = Math.max(0, p.fieldCd - dt);
    p.burstCd = Math.max(0, p.burstCd - dt);
    p.invulnTime = Math.max(0, p.invulnTime - dt);
    p.fieldTime = Math.max(0, p.fieldTime - dt);
    p.attackAnim = Math.max(0, p.attackAnim - dt);
    p.hurtFlash = Math.max(0, p.hurtFlash - dt);

    // Passive HP regen (undead)
    if (p.regenPerSec > 0 && p.hp < p.hpMax) {
      p.hp = Math.min(p.hpMax, p.hp + p.regenPerSec * dt);
    }

    if (inp.attack && p.attackCooldown <= 0) this.playerAttack();

    // Force field DOT
    if (p.fieldTime > 0) {
      const radius = 110;
      for (const e of this.enemies) {
        if (e.dead) continue;
        if (dist(p, e) < radius + e.radius) this.damageEnemy(e, p.damage * 1.4 * dt, true);
      }
      if (Math.random() < 0.6) {
        const a = Math.random() * Math.PI * 2;
        const d = radius * (0.85 + Math.random() * 0.15);
        this.particles.push({ x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d, vx: 0, vy: 0, t: 0.3, life: 0.3, color: '#ff80a0', size: 2 });
      }
    }
  }

  playerAttack() {
    const p = this.player;
    p.attackCooldown = 1 / p.attackSpeed;
    p.attackAnim = 0.25;
    audio.play('attack');

    let target = null; let best = Infinity;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d < p.attackRange + e.radius && d < best) { best = d; target = e; }
    }
    if (target) {
      p.facing = angle(p, target);
      p.flipX = Math.cos(p.facing) < 0;
    }
    const arc = Math.PI / 2;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d > p.attackRange + e.radius) continue;
      const ang = angle(p, e);
      const diff = Math.abs(((ang - p.facing) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
      if (diff < arc) {
        this.damageEnemy(e, p.damage, true);
        p.hp = Math.min(p.hpMax, p.hp + p.damage * p.lifesteal);
      }
    }
    const r = p.attackRange;
    for (let i = 0; i < 8; i++) {
      const a = p.facing + rand(-arc, arc);
      const d = rand(20, r);
      this.particles.push({ x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d, vx: 0, vy: 0, t: 0.15, life: 0.15, color: '#fff0c0', size: rand(2, 4) });
    }
  }

  updateEnemies(dt) {
    const p = this.player;
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.animT += dt; e.atkTimer -= dt;
      if (e.behavior === 'boss') { this.updateBoss(e, dt); continue; }
      const d = dist(e, p);

      if (e.behavior === 'chase') {
        const a = angle(e, p);
        if (d > e.attackRange + e.radius - 4) {
          this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius);
        }
        if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
          this.damagePlayer(e.damage);
          e.atkTimer = e.attackCooldown;
        }
      } else if (e.behavior === 'teleport') {
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          let placed = false;
          for (let tries = 0; tries < 12; tries++) {
            const tA = Math.random() * Math.PI * 2;
            const tD = rand(110, 200);
            const tx = clamp(p.x + Math.cos(tA) * tD, 30, W - 30);
            const ty = clamp(p.y + Math.sin(tA) * tD, 30, H - 30);
            if (!this.collideCircleWithWalls(tx, ty, e.radius)) { e.x = tx; e.y = ty; placed = true; break; }
          }
          if (!placed) {
            const sp = this.findOpenSpawn(p.x + 140, p.y, e.radius);
            e.x = sp.x; e.y = sp.y;
          }
          e.stateTimer = rand(2, 3.5);
          for (let i = 0; i < 10; i++)
            this.particles.push({ x: e.x, y: e.y, vx: rand(-100,100), vy: rand(-100,100), t: 0.4, life: 0.4, color: '#a040ff', size: 3 });
        }
        const a = angle(e, p);
        this.moveWithCollision(e, Math.cos(a) * e.speed * 0.4 * dt, Math.sin(a) * e.speed * 0.4 * dt, e.radius);
        if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
          this.damagePlayer(e.damage); e.atkTimer = e.attackCooldown;
        }
      } else if (e.behavior === 'charge') {
        if (e.stateData.charging) {
          const px = e.x, py = e.y;
          this.moveWithCollision(e, e.stateData.cx * e.speed * 1.8 * dt, e.stateData.cy * e.speed * 1.8 * dt, e.radius);
          e.stateTimer -= dt;
          if (e.stateTimer <= 0 || d < e.attackRange ||
              (Math.abs(e.x - px) < 0.2 && Math.abs(e.y - py) < 0.2)) {
            e.stateData.charging = false; e.stateTimer = rand(1.0, 1.6);
          }
          if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
            this.damagePlayer(e.damage * 1.5);
            e.atkTimer = e.attackCooldown;
            e.stateData.charging = false; e.stateTimer = 1.2;
          }
        } else {
          e.stateTimer -= dt;
          if (e.stateTimer <= 0) {
            const a = angle(e, p);
            e.stateData.cx = Math.cos(a); e.stateData.cy = Math.sin(a);
            e.stateData.charging = true; e.stateTimer = 1.5;
          }
        }
      } else if (e.behavior === 'ranged') {
        const a = angle(e, p);
        const desired = 240;
        if (d < desired - 20) this.moveWithCollision(e, -Math.cos(a) * e.speed * dt, -Math.sin(a) * e.speed * dt, e.radius);
        else if (d > desired + 20) this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius);
        if (e.atkTimer <= 0 && d < e.attackRange) {
          this.projectiles.push({ x: e.x, y: e.y, vx: Math.cos(a) * 260, vy: Math.sin(a) * 260, r: 7, damage: e.damage, life: 2.0, t: 2.0, from: 'enemy', color: '#ff60c0' });
          e.atkTimer = e.attackCooldown;
        }
      }
    }
    this.enemies = this.enemies.filter(e => !e.dead);
  }

  updateBoss(e, dt) {
    const p = this.player;
    e.patternTimer -= dt;
    const d = dist(e, p);
    const a = angle(e, p);
    if (e.patternState === 'idle') {
      if (d > 200) this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius);
      else if (d < 130) this.moveWithCollision(e, -Math.cos(a) * e.speed * 0.4 * dt, -Math.sin(a) * e.speed * 0.4 * dt, e.radius);
      if (e.patternTimer <= 0) {
        const choices = ['claw', 'breath', 'orbs', 'summon', 'slam'];
        e.patternState = choices[Math.floor(Math.random() * choices.length)];
        e.patternTimer = 1.0;
        e.stateData = {};
      }
    } else if (e.patternState === 'claw') {
      if (e.patternTimer < 0.4 && !e.stateData.hit) {
        if (d < 110 + e.radius) this.damagePlayer(e.damage * 1.2);
        e.stateData.hit = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(0.8, 1.4); e.stateData = {}; }
    } else if (e.patternState === 'breath') {
      if (!e.stateData.t) { e.stateData.t = 1.5; e.stateData.dir = a; }
      e.stateData.t -= dt;
      const conAng = e.stateData.dir;
      const arc = Math.PI / 4;
      const reach = 320;
      for (let i = 0; i < 4; i++) {
        const aa = conAng + rand(-arc, arc);
        const dd = rand(0, reach);
        this.particles.push({ x: e.x + Math.cos(aa) * dd, y: e.y + Math.sin(aa) * dd, vx: 0, vy: 0, t: 0.3, life: 0.3, color: '#ff5020', size: rand(3,6) });
      }
      if (d < reach) {
        const aP = angle(e, p);
        const diff = Math.abs(((aP - conAng) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
        if (diff < arc) this.damagePlayer(e.damage * 0.4 * dt * 4);
      }
      if (e.stateData.t <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.2, 1.8); e.stateData = {}; }
    } else if (e.patternState === 'orbs') {
      if (!e.stateData.fired) {
        const N = 10;
        for (let i = 0; i < N; i++) {
          const aa = (i / N) * Math.PI * 2 + rand(-0.1, 0.1);
          this.projectiles.push({ x: e.x, y: e.y, vx: Math.cos(aa) * 200, vy: Math.sin(aa) * 200, r: 10, damage: e.damage * 0.7, life: 3, t: 3, from: 'enemy', color: '#a040ff' });
        }
        e.stateData.fired = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.0, 1.5); e.stateData = {}; }
    } else if (e.patternState === 'summon') {
      if (!e.stateData.fired) {
        const scale = phaseScale(10);
        for (let i = 0; i < 3; i++) this.spawnEnemy('imp', scale);
        e.stateData.fired = true;
        this.floatTexts.push({ x: e.x, y: e.y - e.radius - 20, t: 1.4, text: 'INVOCA SERVOS!', color: '#ff6020' });
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.5, 2.5); e.stateData = {}; }
    } else if (e.patternState === 'slam') {
      if (!e.stateData.done && e.patternTimer < 0.3) {
        this.shake = Math.min(20, this.shake + 14);
        const radius = 200;
        if (d < radius + e.radius) this.damagePlayer(e.damage * 1.4);
        for (let i = 0; i < 24; i++) {
          const aa = Math.random() * Math.PI * 2;
          const dd = rand(40, radius);
          this.particles.push({ x: e.x + Math.cos(aa)*dd, y: e.y + Math.sin(aa)*dd, vx:0, vy:0, t:0.5, life:0.5, color:'#ff3010', size: rand(3,6) });
        }
        e.stateData.done = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.5, 2.2); e.stateData = {}; }
    }
  }

  updateProjectiles(dt) {
    const p = this.player;
    for (const pr of this.projectiles) {
      if (pr.dead) continue;
      pr.x += pr.vx * dt; pr.y += pr.vy * dt;
      pr.t -= dt;
      if (pr.t <= 0) { pr.dead = true; continue; }
      if (pr.x < -20 || pr.x > W + 20 || pr.y < -20 || pr.y > H + 20) { pr.dead = true; continue; }
      if (this.collideCircleWithWalls(pr.x, pr.y, pr.r)) {
        pr.dead = true;
        for (let i = 0; i < 4; i++)
          this.particles.push({ x: pr.x, y: pr.y, vx: rand(-60,60), vy: rand(-60,60), t: 0.25, life: 0.25, color: pr.color, size: 2 });
        continue;
      }
      if (pr.from === 'player') {
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (dist(pr, e) < pr.r + e.radius) {
            this.damageEnemy(e, pr.damage, true);
            p.hp = Math.min(p.hpMax, p.hp + pr.damage * p.lifesteal);
            pr.dead = true; break;
          }
        }
      } else {
        if (dist(pr, p) < pr.r + p.r) { this.damagePlayer(pr.damage); pr.dead = true; }
      }
    }
    this.projectiles = this.projectiles.filter(p => !p.dead);
  }

  updateParticles(dt) {
    for (const pa of this.particles) { pa.x += (pa.vx || 0) * dt; pa.y += (pa.vy || 0) * dt; pa.t -= dt; }
    this.particles = this.particles.filter(p => p.t > 0);
  }

  updateFloatTexts(dt) {
    for (const ft of this.floatTexts) { ft.y -= 30 * dt; ft.t -= dt; }
    this.floatTexts = this.floatTexts.filter(f => f.t > 0);
  }

  checkClear() {
    if (this.cleared) return;
    if (this.enemies.length === 0) {
      this.cleared = true;
      // Save run snapshot when a phase is cleared
      this.persistSnapshot();
      if (this.phase >= PHASES) {
        audio.play('victory');
        clearCurrentSave();
        this.onVictory();
      } else this.onPhaseClear(this.phase);
    }
  }

  // Snapshot player state (for save game)
  snapshot() {
    const p = this.player;
    return {
      phase: this.phase + 1, // the next phase to start when continuing
      kills: p.kills,
      level: p.level,
      classId: p.classId,
      damage: p.damage,
      attackSpeed: p.attackSpeed,
      defense: p.defense,
      lifesteal: p.lifesteal,
      moveSpeed: p.moveSpeed,
      hp: p.hp,
      hpMax: p.hpMax,
      attackRange: p.attackRange,
      dodgeChance: p.dodgeChance,
      regenPerSec: p.regenPerSec,
      className: p.className,
      classColor: p.classColor,
    };
  }

  persistSnapshot() {
    try { saveProgress(this.snapshot()); } catch (_e) { /* ignore */ }
  }

  // Continue from a saved run: load player stats and start at next phase
  loadFromSave(snap) {
    const p = this.player;
    p.classId = snap.classId || p.classId;
    p.className = snap.className || p.className;
    p.classColor = snap.classColor || p.classColor;
    p.kills = snap.kills || 0;
    p.level = snap.level || 1;
    p.damage = snap.damage || p.damage;
    p.attackSpeed = snap.attackSpeed || p.attackSpeed;
    p.defense = snap.defense || p.defense;
    p.lifesteal = snap.lifesteal != null ? snap.lifesteal : p.lifesteal;
    p.moveSpeed = snap.moveSpeed || p.moveSpeed;
    p.hpMax = snap.hpMax || p.hpMax;
    p.hp = snap.hp || p.hpMax;
    p.attackRange = snap.attackRange || p.attackRange;
    p.dodgeChance = snap.dodgeChance != null ? snap.dodgeChance : p.dodgeChance;
    p.regenPerSec = snap.regenPerSec != null ? snap.regenPerSec : p.regenPerSec;
    const phase = Math.max(1, Math.min(PHASES, snap.phase || 1));
    this.startPhase(phase);
    this.emitUi();
  }

  // ===== RENDER =====
  render(ctx) {
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-this.shake, this.shake), rand(-this.shake, this.shake));

    this.drawBackground(ctx);
    this.drawWalls(ctx);
    for (const npc of this.npcs) this.drawNpc(ctx, npc);
    if (this.player.fieldTime > 0) this.drawField(ctx);
    for (const e of this.enemies) this.drawEnemy(ctx, e);
    this.drawPlayer(ctx);
    for (const pr of this.projectiles) this.drawProjectile(ctx, pr);
    for (const pa of this.particles) {
      const alpha = clamp(pa.t / pa.life, 0, 1);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = pa.color;
      ctx.fillRect(pa.x - pa.size / 2, pa.y - pa.size / 2, pa.size, pa.size);
    }
    ctx.globalAlpha = 1;
    ctx.font = "bold 18px 'VT323', monospace";
    ctx.textAlign = 'center';
    for (const ft of this.floatTexts) {
      ctx.globalAlpha = clamp(ft.t, 0, 1);
      ctx.fillStyle = '#000'; ctx.fillText(ft.text, ft.x + 1, ft.y + 1);
      ctx.fillStyle = ft.color; ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  drawBackground(ctx) {
    const grad = ctx.createRadialGradient(W/2, H/2, 100, W/2, H/2, 800);
    grad.addColorStop(0, '#1a0606');
    grad.addColorStop(1, '#060101');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = 'rgba(60, 16, 16, 0.4)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();
      const seed = (i * 47 + this.phase * 13) % 1000;
      const x = (seed * 13) % W;
      const y = (seed * 7) % H;
      ctx.moveTo(x, y);
      ctx.lineTo(x + 60, y + 22);
      ctx.lineTo(x + 90, y + 8);
      ctx.stroke();
    }
  }

  drawWalls(ctx) {
    if (!this.walls || !this.walls.length) return;
    for (const w of this.walls) {
      const grad = ctx.createLinearGradient(w.x, w.y, w.x, w.y + w.h);
      grad.addColorStop(0, '#2a0606');
      grad.addColorStop(0.5, '#1a0303');
      grad.addColorStop(1, '#0a0101');
      ctx.fillStyle = grad;
      ctx.fillRect(w.x, w.y, w.w, w.h);
      ctx.strokeStyle = 'rgba(90, 20, 20, 0.55)';
      ctx.lineWidth = 1;
      const brick = 32;
      for (let by = w.y + brick; by < w.y + w.h; by += brick) {
        ctx.beginPath(); ctx.moveTo(w.x, by); ctx.lineTo(w.x + w.w, by); ctx.stroke();
      }
      for (let bx = w.x + brick; bx < w.x + w.w; bx += brick) {
        ctx.beginPath(); ctx.moveTo(bx, w.y); ctx.lineTo(bx, w.y + w.h); ctx.stroke();
      }
      ctx.fillStyle = 'rgba(120, 36, 28, 0.35)';
      ctx.fillRect(w.x, w.y, w.w, 3);
      ctx.strokeStyle = '#3a0808';
      ctx.lineWidth = 2;
      ctx.strokeRect(w.x + 0.5, w.y + 0.5, w.w - 1, w.h - 1);
      const seed = (w.x * 7 + w.y * 13) | 0;
      const cnt = ((seed >> 3) & 3);
      for (let i = 0; i < cnt; i++) {
        const px = w.x + ((seed * (i + 1) * 17) % Math.max(1, w.w - 4));
        const py = w.y + (((seed >> 2) * (i + 1) * 11) % Math.max(1, w.h - 4));
        ctx.fillStyle = 'rgba(255, 60, 20, 0.6)';
        ctx.fillRect(px, py, 2, 2);
      }
    }
  }

  drawField(ctx) {
    const p = this.player;
    const r = 110;
    const t = (Date.now() / 200) % (Math.PI * 2);
    ctx.save();
    ctx.translate(p.x, p.y); ctx.rotate(t);
    ctx.strokeStyle = '#ff80a0'; ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
    ctx.lineWidth = 1; ctx.globalAlpha = 0.3;
    ctx.beginPath(); ctx.arc(0, 0, r - 8, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, r + 8, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      ctx.fillStyle = '#ff80a0'; ctx.globalAlpha = 0.6;
      ctx.fillRect(Math.cos(a) * r - 3, Math.sin(a) * r - 3, 6, 6);
    }
    ctx.restore();
  }

  drawPlayer(ctx) {
    const p = this.player;
    if (p.dead) return;
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 14, 14, 5, 0, 0, Math.PI * 2); ctx.fill();

    if (p.invulnTime > 0) {
      const t = (Date.now() / 100) % (Math.PI * 2);
      ctx.strokeStyle = '#80c0ff'; ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
      ctx.beginPath(); ctx.arc(p.x, p.y, 26 + Math.sin(t) * 3, 0, Math.PI * 2); ctx.stroke();
      ctx.globalAlpha = 1;
    }

    let frame;
    if (p.attackAnim > 0) {
      const idx = Math.min(SPR.attack.length - 1, Math.floor((1 - p.attackAnim / 0.25) * SPR.attack.length));
      frame = SPR.attack[idx];
    } else if (p.moving) frame = SPR.walk[p.animFrame % SPR.walk.length];
    else frame = SPR.idle[p.animFrame % SPR.idle.length];

    const size = 64;
    const sx = frame.x * SPR.cell;
    const sy = frame.y * SPR.cell;

    ctx.save();
    ctx.translate(p.x, p.y);
    if (p.flipX) ctx.scale(-1, 1);
    if (p.hurtFlash > 0) {
      ctx.filter = 'brightness(2) sepia(1) hue-rotate(-30deg) saturate(5)';
    } else if (p.classId === 'undead') {
      ctx.filter = 'hue-rotate(80deg) saturate(0.55) brightness(0.85)';
    } else if (p.classId === 'ghost') {
      ctx.filter = 'hue-rotate(180deg) saturate(0.4) brightness(1.6)';
      ctx.globalAlpha = 0.7;
    }
    if (this.spriteImg) {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.spriteImg, sx, sy, SPR.cell, SPR.cell, -size/2, -size/2 - 8, size, size);
    } else {
      ctx.fillStyle = p.classColor || '#c01818';
      ctx.fillRect(-12, -20, 24, 32);
    }
    ctx.restore();

    if (p.attackAnim > 0) {
      const t = 1 - p.attackAnim / 0.25;
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.facing);
      ctx.strokeStyle = '#fff0c0'; ctx.lineWidth = 4;
      ctx.globalAlpha = (1 - t) * 0.9;
      ctx.beginPath();
      const arc = Math.PI / 2;
      ctx.arc(0, 0, p.attackRange, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.lineWidth = 2; ctx.globalAlpha *= 0.6;
      ctx.beginPath();
      ctx.arc(0, 0, p.attackRange - 10, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.restore();
    }
  }

  drawEnemy(ctx, e) {
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(e.x, e.y + e.radius - 2, e.radius * 0.8, e.radius * 0.25, 0, 0, Math.PI * 2);
    ctx.fill();

    if (e.isBoss) { this.drawBoss(ctx, e); return; }

    const bob = Math.sin(e.animT * 5) * 2;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    const r = e.radius;
    // horns
    ctx.fillStyle = '#1a0202';
    ctx.beginPath();
    ctx.moveTo(-r * 0.4, -r * 0.9); ctx.lineTo(-r * 0.7, -r * 1.5); ctx.lineTo(-r * 0.2, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.4, -r * 0.9); ctx.lineTo(r * 0.7, -r * 1.5); ctx.lineTo(r * 0.2, -r * 1.0); ctx.closePath(); ctx.fill();
    // body
    ctx.fillStyle = e.color;
    ctx.beginPath();
    ctx.moveTo(-r, r); ctx.lineTo(-r * 0.6, -r * 0.6); ctx.lineTo(0, -r);
    ctx.lineTo(r * 0.6, -r * 0.6); ctx.lineTo(r, r);
    ctx.lineTo(r * 0.7, r * 1.1); ctx.lineTo(-r * 0.7, r * 1.1); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(0, -r * 0.3, r * 0.55, r * 0.45, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = e.eye;
    ctx.shadowColor = e.eye; ctx.shadowBlur = 6;
    ctx.fillRect(-r * 0.35, -r * 0.35, 4, 4);
    ctx.fillRect(r * 0.2, -r * 0.35, 4, 4);
    ctx.shadowBlur = 0;
    if (e.type === 'brute' || e.type === 'warlock') {
      ctx.fillStyle = '#fff0c0';
      for (let i = -2; i <= 2; i++) ctx.fillRect(i * 3 - 1, 0, 2, 4);
    }
    ctx.restore();
    if (e.hp < e.hpMax) {
      const w = e.radius * 2;
      ctx.fillStyle = '#1a0303';
      ctx.fillRect(e.x - w/2, e.y - e.radius - 12, w, 4);
      ctx.fillStyle = '#ff3030';
      ctx.fillRect(e.x - w/2, e.y - e.radius - 12, w * (e.hp / e.hpMax), 4);
    }
  }

  drawBoss(ctx, e) {
    const r = e.radius;
    const bob = Math.sin(e.animT * 2) * 3;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.fillStyle = '#0a0000';
    ctx.beginPath();
    ctx.moveTo(-r * 0.6, -r * 0.7); ctx.lineTo(-r * 1.1, -r * 1.8); ctx.lineTo(-r * 0.3, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.6, -r * 0.7); ctx.lineTo(r * 1.1, -r * 1.8); ctx.lineTo(r * 0.3, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#180202';
    ctx.beginPath();
    ctx.moveTo(-r * 0.5, -r * 0.2); ctx.lineTo(-r * 2.2, -r * 0.6); ctx.lineTo(-r * 2.0, r * 0.6); ctx.lineTo(-r * 0.5, r * 0.4); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.5, -r * 0.2); ctx.lineTo(r * 2.2, -r * 0.6); ctx.lineTo(r * 2.0, r * 0.6); ctx.lineTo(r * 0.5, r * 0.4); ctx.closePath(); ctx.fill();
    const grad = ctx.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.2);
    grad.addColorStop(0, '#5a0606'); grad.addColorStop(1, '#1a0202');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.ellipse(0, 0, r * 1.0, r * 1.2, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ff2000'; ctx.shadowColor = '#ff4000'; ctx.shadowBlur = 20;
    ctx.fillRect(-r * 0.4, -r * 0.25, 10, 10);
    ctx.fillRect(r * 0.3, -r * 0.25, 10, 10);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fff0c0';
    for (let i = -3; i <= 3; i++) ctx.fillRect(i * 8 - 2, r * 0.25, 5, 9);
    ctx.restore();
    const w = Math.min(W * 0.6, 800);
    const x = W / 2 - w / 2;
    const y = 60;
    ctx.fillStyle = '#1a0303'; ctx.fillRect(x - 2, y - 2, w + 4, 22);
    ctx.fillStyle = '#3a0606'; ctx.fillRect(x, y, w, 18);
    ctx.fillStyle = '#c01010'; ctx.fillRect(x, y, w * (e.hp / e.hpMax), 18);
    ctx.font = "bold 20px 'Cinzel', serif"; ctx.textAlign = 'center';
    ctx.fillStyle = '#ffd9a3';
    ctx.fillText(e.name.toUpperCase(), W / 2, y - 8);
  }

  drawNpc(ctx, npc) {
    npc.bobT += 0.016;
    const bob = Math.sin(npc.bobT * 2) * 3;
    ctx.save();
    ctx.translate(npc.x, npc.y + bob);
    ctx.fillStyle = 'rgba(120,180,255,0.2)';
    ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#a0c8ff'; ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.moveTo(-14, 14); ctx.lineTo(-14, -8);
    ctx.quadraticCurveTo(0, -22, 14, -8);
    ctx.lineTo(14, 14); ctx.lineTo(8, 10); ctx.lineTo(0, 14);
    ctx.lineTo(-8, 10); ctx.closePath(); ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#000';
    ctx.fillRect(-6, -8, 3, 4); ctx.fillRect(3, -8, 3, 4);
    ctx.restore();
    const p = this.player;
    if (dist(p, npc) < 70) {
      ctx.font = "16px 'VT323', monospace"; ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.fillText('[ E ] FALAR', npc.x, npc.y - 32);
    }
    ctx.font = "14px 'Cinzel', serif"; ctx.textAlign = 'center';
    ctx.fillStyle = '#a0c8ff';
    ctx.fillText(npc.name, npc.x, npc.y - 22);
  }

  drawProjectile(ctx, pr) {
    ctx.save();
    ctx.fillStyle = pr.color; ctx.shadowColor = pr.color; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.arc(pr.x, pr.y, pr.r, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}
