// Game engine for "INFERNO" - top-down action roguelite.
// Renders to a canvas. Uses raf loop. Player has 8-direction movement,
// medium-range slash attack, 3 active skills, 10 phases, attribute selection.

export const W = 1280;
export const H = 720;

export const PHASES = 10;

// Player base stats
export const BASE = {
  hp: 100,
  damage: 15,
  attackSpeed: 1.0, // attacks per second
  defense: 5,
  lifesteal: 0.05,
  moveSpeed: 220,
  attackRange: 110, // medium range slash
};

// Per-level multiplier (every 5 kills => +5% all)
export const LEVEL_BONUS = 0.05;

// Character classes - each with passive bonuses applied on game start
export const CLASSES = {
  undead: {
    id: 'undead',
    name: 'MORTO-VIVO',
    tagline: 'A CARNE QUE NÃO MORRE',
    color: '#7ab84a',
    description: 'Resistente e tenaz. Regenera vida lentamente; carrega o peso da eternidade.',
    bonuses: {
      hpMul: 1.40,
      defenseMul: 1.30,
      moveSpeedMul: 0.92,
      damageMul: 0.95,
      regenPerSec: 1.5,
    },
    passives: [
      '+40% Vida Máxima',
      '+30% Defesa',
      'Regenera 1.5 HP/s',
      '-8% Velocidade de movimento',
    ],
  },
  vampire: {
    id: 'vampire',
    name: 'VAMPIRO',
    tagline: 'A SEDE QUE NUNCA CESSA',
    color: '#c01030',
    description: 'Mestre do roubo de vida. Cada golpe alimenta sua existência amaldiçoada.',
    bonuses: {
      lifestealAdd: 0.05,
      damageMul: 1.10,
      hpMul: 0.92,
    },
    passives: [
      '+5% Roubo de Vida (10% total)',
      '+10% Dano',
      '-8% Vida Máxima',
    ],
  },
  ghost: {
    id: 'ghost',
    name: 'FANTASMA',
    tagline: 'O QUE ATRAVESSA AS PAREDES',
    color: '#80c0ff',
    description: 'Esquiva moderada de golpes. Veloz e furtivo, mas frágil ao toque.',
    bonuses: {
      dodgeChance: 0.25,
      moveSpeedMul: 1.18,
      attackSpeedMul: 1.10,
      hpMul: 0.85,
      defenseMul: 0.80,
    },
    passives: [
      '25% chance de esquivar de golpes',
      '+18% Velocidade de movimento',
      '+10% Velocidade de ataque',
      '-15% Vida Máxima, -20% Defesa',
    ],
  },
};

// Sprite mapping (from /assets/character.png 256x288, cells 32x32)
export const SPR = {
  cell: 32,
  idle: [{ x: 0, y: 0 }, { x: 1, y: 0 }],
  walk: [{ x: 0, y: 3 }, { x: 1, y: 3 }, { x: 2, y: 3 }, { x: 3, y: 3 }],
  attack: [{ x: 3, y: 8 }, { x: 4, y: 8 }, { x: 5, y: 8 }],
  death: [{ x: 0, y: 6 }, { x: 1, y: 6 }, { x: 2, y: 6 }, { x: 3, y: 6 }],
};

export function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
export function dist(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y; return Math.hypot(dx, dy);
}
export function angle(a, b) { return Math.atan2(b.y - a.y, b.x - a.x); }
export function rand(min, max) { return Math.random() * (max - min) + min; }

// Enemy archetypes - terrifying demons
export const ENEMY_TYPES = {
  imp: {
    name: 'Imp',
    color: '#ff3a14',
    eye: '#ffff80',
    radius: 14,
    hp: 35, damage: 8, speed: 130,
    behavior: 'chase',
    attackRange: 26,
    attackCooldown: 0.9,
  },
  brute: {
    name: 'Brute Demon',
    color: '#7a0c0c',
    eye: '#ff4040',
    radius: 22,
    hp: 110, damage: 18, speed: 75,
    behavior: 'chase',
    attackRange: 36,
    attackCooldown: 1.4,
  },
  shade: {
    name: 'Shade',
    color: '#1a0606',
    eye: '#ff80ff',
    radius: 13,
    hp: 45, damage: 10, speed: 110,
    behavior: 'teleport',
    attackRange: 30,
    attackCooldown: 1.2,
  },
  hound: {
    name: 'Hellhound',
    color: '#3a0808',
    eye: '#ff2000',
    radius: 14,
    hp: 55, damage: 12, speed: 180,
    behavior: 'charge',
    attackRange: 28,
    attackCooldown: 1.0,
  },
  warlock: {
    name: 'Warlock',
    color: '#4a0a3a',
    eye: '#ff60a0',
    radius: 16,
    hp: 60, damage: 14, speed: 70,
    behavior: 'ranged',
    attackRange: 320,
    attackCooldown: 1.8,
  },
};

// Boss config
export const BOSS = {
  name: 'Belial, o Arquidemônio',
  color: '#2a0202',
  eye: '#ff2000',
  radius: 56,
  hp: 1800,
  damage: 28,
  speed: 70,
};

// Phase composition (which enemies appear at each phase)
export const PHASE_SPAWNS = [
  { count: 6,  types: ['imp'] },                                   // 1
  { count: 7,  types: ['imp', 'hound'] },                          // 2
  { count: 8,  types: ['imp', 'hound', 'shade'] },                 // 3
  { count: 9,  types: ['imp', 'hound', 'brute'] },                 // 4
  { count: 10, types: ['hound', 'shade', 'warlock'] },             // 5
  { count: 11, types: ['imp', 'brute', 'warlock'] },               // 6
  { count: 12, types: ['hound', 'shade', 'brute', 'warlock'] },    // 7
  { count: 13, types: ['imp', 'hound', 'shade', 'brute'] },        // 8
  { count: 14, types: ['shade', 'brute', 'warlock', 'hound'] },    // 9
  { count: 0,  types: [], boss: true },                            // 10 - boss only
];

// Difficulty scaling per phase
export function phaseScale(phase) {
  return {
    hpMul: 1 + (phase - 1) * 0.20,
    dmgMul: 1 + (phase - 1) * 0.12,
  };
}
