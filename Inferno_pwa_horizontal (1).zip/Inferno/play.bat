@echo off
REM Inicia um servidor local para jogar o build estatico (Windows)
REM Requer Python instalado

cd /d "%~dp0build"
if errorlevel 1 (
    echo Pasta build\ nao encontrada
    pause
    exit /b 1
)

echo.
echo ============================================
echo   INFERNO - Servidor local iniciando...
echo ============================================
echo.
echo   Abra no navegador: http://localhost:8080
echo.
echo   Pressione Ctrl+C para parar.
echo.

where python >nul 2>&1
if %errorlevel% == 0 (
    python -m http.server 8080
    goto :eof
)

where py >nul 2>&1
if %errorlevel% == 0 (
    py -m http.server 8080
    goto :eof
)

where npx >nul 2>&1
if %errorlevel% == 0 (
    npx serve -l 8080 .
    goto :eof
)

echo ERRO: Python ou Node nao encontrado.
echo Instale Python (https://python.org) ou Node (https://nodejs.org).
pause
