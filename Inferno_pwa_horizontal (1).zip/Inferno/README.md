# 🩸 INFERNO — O Caçador Desce

Jogo de ação top-down em estilo masmorra demoníaca, escrito em React 19 + Canvas 2D + Web Audio API.

> **Sem nome. Sem rosto. Sem emoções.** Uma entidade firmada num pacto antigo que persegue os demônios até o último eco. Belial aguarda, dez andares abaixo.

---

## 📦 Conteúdo do pacote

```
Inferno/
├── build/         ← Versão pronta para jogar (build estático)
│   ├── index.html        ← abra com um servidor local (instruções abaixo)
│   ├── assets/character.png
│   └── static/css/, static/js/
├── source/        ← Código-fonte completo (React + JS)
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── ...configs
└── README.md      ← este arquivo
```

---

## 🎮 Como jogar (rápido)

### Opção A — Abrir o build pronto

Devido à política de segurança dos navegadores, **não é possível** simplesmente dar duplo-clique em `build/index.html`. Você precisa servir os arquivos por um servidor local.

**Em qualquer sistema** (com Python instalado):
```bash
cd Inferno/build
python3 -m http.server 8080
```
Depois abra: **http://localhost:8080**

**Com Node** (sem instalar nada extra usando npx):
```bash
cd Inferno/build
npx serve .
```

**Windows** (sem terminal): instale [Servez](https://greggman.github.io/servez/), aponte para a pasta `build` e clique em START.

### Opção B — Rodar o código-fonte (modo desenvolvedor)

```bash
cd Inferno/source
yarn install        # (ou npm install)
yarn start
```
Abre em http://localhost:3000

---

## 🎯 Controles

### Desktop (teclado + mouse)
| Tecla | Ação |
|-------|------|
| `W A S D` ou `↑ ← ↓ →` | Movimento (8 direções) |
| `Espaço` / `J` / Clique | Atacar |
| `Q` | Invulnerabilidade (5s, cd 10s) |
| `R` | Campo de Força (3s, cd 10s) |
| `F` | Disparo Arcano radial (cd 10s) |
| `E` | Falar com NPC |
| `M` | Mutar/Desmutar áudio |

### Mobile / Touch
- **Joystick virtual** (canto inferior esquerdo) — movimento
- **Botão grande à direita** — ataque
- **3 botões pequenos** — habilidades
- **Botão azul "FALAR"** — aparece perto do NPC

---

## 🩸 Mecânicas

### Sistema de Classes
Escolhido antes de cada nova descida — cada classe traz passivas únicas:

| Classe | Passivas |
|--------|----------|
| **MORTO-VIVO** | +40% HP máx, +30% defesa, regenera 1.5 HP/s, -8% velocidade |
| **VAMPIRO** | +5% roubo de vida (10% total), +10% dano, -8% HP |
| **FANTASMA** | 25% chance de esquivar, +18% velocidade, +10% velocidade de ataque, -15% HP, -20% defesa |

### Progressão
- **10 andares** com masmorra labiríntica gerada proceduralmente
- A cada **5 abates** → level-up automático: +5% em todos os atributos
- Ao final de cada andar → escolha 1 dádiva sombria:
  - **Fúria** +15% dano
  - **Frenesi** +20% velocidade de ataque
  - **Vampirismo** +10% roubo de vida
  - **Carne dura** +25% defesa
  - **Vitalidade** +100% HP máximo

### Inimigos
- **Imp** — assédio rápido em melee
- **Brute** — alto HP e dano corpo-a-corpo
- **Shade** — teleporta-se em volta do jogador
- **Hellhound** — cargas em linha reta
- **Warlock** — mantém distância e dispara projéteis

### Boss final (Andar 10) — Belial, o Arquidemônio
5 ataques rotativos: garra pesada, sopro de fogo em cone, orbes radiais, invocação de servos, e onda de choque massiva.

### NPC — Alma Perdida (Andar 2)
Diálogo + bênção opcional (+3% vampirismo permanente e cura total).

---

## 💾 Save / Continuar

O progresso é salvo automaticamente no **localStorage do navegador** ao final de cada andar.

- **CONTINUAR** aparece no menu se houver uma run em andamento
- **NOVA DESCIDA** sempre começa do zero
- **APAGAR SAVE** limpa todos os dados salvos
- Morrer **apaga o save atual** (mas mantém o registro do melhor andar atingido)

> ⚠️ O save fica vinculado ao navegador/domínio. Trocar de navegador ou limpar dados do site apaga o progresso.

---

## 🎵 Áudio

A trilha sonora e os SFX são **gerados proceduralmente** pela Web Audio API — nenhum arquivo de áudio externo é usado. Isso significa:

- Funciona 100% offline depois de carregado
- Trilha dark ambient muda quando o boss aparece
- Botão de mute (♫/♪) no canto superior direito
- Áudio inicia apenas depois do primeiro clique (política dos navegadores)

---

## 🧱 Stack & arquitetura

- **React 19** (CRA + craco) — wrapper de UI/screens
- **Canvas 2D API** — renderização do jogo
- **Web Audio API** — música procedural + SFX
- **localStorage** — persistência

Estrutura de pastas relevantes:
```
src/
├── App.js, App.css, index.js, index.css
└── game/
    ├── InfernoGame.jsx   — componente React, telas, input, HUD, touch
    ├── Engine.js          — motor: update loop, IA, render, colisão
    ├── config.js          — constantes, classes, inimigos, fases
    ├── AudioManager.js    — música procedural + SFX
    └── Save.js            — sistema de save/load via localStorage
public/
└── assets/character.png   — spritesheet 32x32 do Caçador
```

---

## 🛠️ Solução de problemas

**A página não carrega ao dar duplo-clique no index.html**
→ Os navegadores bloqueiam arquivos via `file://`. Use um servidor local (instruções no topo).

**O áudio não toca**
→ Clique em qualquer lugar da página primeiro (política de autoplay). O botão ♫ no canto superior alterna o mudo.

**As fontes ficam estranhas**
→ As fontes vêm do Google Fonts. Sem internet na primeira execução, o navegador cairá para a fonte padrão — o jogo continua funcionando perfeitamente.

**Não consigo passar de uma sala estreita**
→ Ataques (`F`/`R`) atravessam paredes? Não — projéteis colidem com paredes. Procure rotas alternativas no labirinto.

---

## 📜 Lore

> Antes do tempo, quando o véu entre os mundos ainda era pele, um homem — ou o que um dia foi homem — firmou um pacto com algo mais antigo que os deuses.
>
> Cedeu o **nome**, para que nenhum demônio pudesse invocá-lo.
> Cedeu o **rosto**, para que nenhum espelho o reconhecesse.
> Cedeu as **emoções**, para que medo, dor ou piedade nunca atrasassem o golpe.
>
> O que sobrou já não é humano. Já não está vivo. Mas também nunca morreu.
> É apenas uma função. Um recipiente. Ódio infinito destilado num único propósito.
>
> Hoje, o rastro o trouxe ao próprio Inferno.

---

Boa caçada. **Desça.**
