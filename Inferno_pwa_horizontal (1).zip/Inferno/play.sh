#!/bin/bash
# Inicia um servidor local para jogar o build estático
# Requer Python 3 instalado

cd "$(dirname "$0")/build" || { echo "Pasta build/ não encontrada"; exit 1; }
echo ""
echo "============================================"
echo "  INFERNO - Servidor local iniciando..."
echo "============================================"
echo ""
echo "  Abra no navegador: http://localhost:8080"
echo ""
echo "  Pressione Ctrl+C para parar."
echo ""

# Tenta Python 3, depois Python 2, depois Node
if command -v python3 &> /dev/null; then
    python3 -m http.server 8080
elif command -v python &> /dev/null; then
    python -m SimpleHTTPServer 8080
elif command -v npx &> /dev/null; then
    npx serve -l 8080 .
else
    echo "ERRO: Python ou Node nao encontrado. Instale um deles ou use um servidor local manualmente."
    exit 1
fi
